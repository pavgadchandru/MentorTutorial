CREATE TABLE IF NOT EXISTS technologies (
    tech_id INT AUTO_INCREMENT,
    skillname VARCHAR(255) NOT NULL,
    prerequisites TEXT,
    PRIMARY KEY (tech_id)
)  ENGINE=INNODB;