CREATE TABLE IF NOT EXISTS mentorcalendar (
    mentor_id INT AUTO_INCREMENT,
    start_date DATE,
    end_date DATE,
    start_time DATE,
    end_time DATE,    
    PRIMARY KEY (mentor_id)
)  ENGINE=INNODB;