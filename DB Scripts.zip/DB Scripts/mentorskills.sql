CREATE TABLE IF NOT EXISTS mentorskills (
    mentor_id INT AUTO_INCREMENT,
    skillid INT NOT NULL,
    skillexp INT NOT NULL,
    skillratings DOUBLE NULL,    
    trainingsdelivered INT NOT NULL,
    facilitiesoffered TEXT,
    PRIMARY KEY (mentor_id)
)  ENGINE=INNODB;