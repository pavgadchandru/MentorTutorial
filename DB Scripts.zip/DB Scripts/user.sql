CREATE TABLE IF NOT EXISTS user (
    user_id INT AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    firstname VARCHAR(255) NOT NULL,
    lastname VARCHAR(255) NOT NULL,
    contactnumber VARCHAR(255) NOT NULL,    
    registered_date DATE,
    registeredcode VARCHAR(255) NOT NULL,
    activestatus TEXT,
    PRIMARY KEY (user_id)
)  ENGINE=INNODB;