CREATE TABLE IF NOT EXISTS trainings (
    training_id INT AUTO_INCREMENT,
    user_id VARCHAR(255) NOT NULL,
    mentor_id VARCHAR(255) NOT NULL,
    tech_id VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    progress VARCHAR(255) NOT NULL,
    start_date DATE,
    end_date DATE,
    start_time TIME,
    end_time TIME,
    amountreceived DOUBLE NOT NULL,
    PRIMARY KEY (training_id)
)  ENGINE=INNODB;