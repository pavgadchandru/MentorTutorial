CREATE TABLE IF NOT EXISTS payments (
    payment_id INT AUTO_INCREMENT,
    mentor_id VARCHAR(255) NOT NULL,
    training_id VARCHAR(255) NOT NULL,
    txntype VARCHAR(255) NOT NULL,
    amountreceived DOUBLE NOT NULL,
    remarks TEXT,
    PRIMARY KEY (payment_id)
)  ENGINE=INNODB;