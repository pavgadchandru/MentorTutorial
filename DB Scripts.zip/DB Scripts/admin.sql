CREATE TABLE IF NOT EXISTS admin (
    admin_id INT AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,    
    PRIMARY KEY (admin_id)
)  ENGINE=INNODB;