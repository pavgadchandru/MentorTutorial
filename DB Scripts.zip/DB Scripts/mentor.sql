CREATE TABLE IF NOT EXISTS mentor (
    mentor_id INT AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    mentorlinkedinurl VARCHAR(255) NULL,	
    registered_date DATE,
    registeredcode VARCHAR(255) NOT NULL,
    totalexp INT NOT NULL,
    activestatus TEXT,
    PRIMARY KEY (mentor_id)
)  ENGINE=INNODB;