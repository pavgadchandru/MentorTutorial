export * from './dashboard/dashboard.component';
export * from './rights/rights.component';
export * from './user/user.component';
export * from './admin.component';