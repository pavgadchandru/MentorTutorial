import { Component } from '@angular/core';
 
  @Component({
    template: `<h1>Dashboard Component</h1>`,
  })
  export class DashboardComponent {
    title = '';
  }