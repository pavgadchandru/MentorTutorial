export class repos {
    id: string;
    name: string;
    html_url: string;
    description: string;
}