package com.mentor.springrest.mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MentorDBRestMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(MentorDBRestMySqlApplication.class, args);
	}
}
