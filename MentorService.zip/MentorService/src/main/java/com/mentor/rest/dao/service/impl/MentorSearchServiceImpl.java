package com.mentor.rest.dao.service.impl;

import org.springframework.web.bind.annotation.RequestMapping;

public class MentorSearchServiceImpl {

	public String mentorSearchServiceImpl() {
		
	}

}