
package com.mentor.rest.model;


public class Training {

	private String id;
	private String name;
	private String status;
	private String progress;
	private String amountreceived;
	private Date startdate;
	private Date enddate;
	private Datetime starttime;
	private Datetime endtime;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProgress() {
		return progress;
	}

	public void setProgress(String progress) {
		this.progress = progress;
	}

	public String getAmtreceived() {
		return amtreceived;
	}

	public void setAmtreceived(String amtreceived) {
		this.amtreceived = amtreceived;
	}
}
