
package com.mentor.rest.dao.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.mentor.rest.model.Mentor;


@Repository
public class MentorServiceImpl implements MentorService {

	private Map<String, Mentor> mapOfMentor = new HashMap<String, Mentor>();

	public void searchMentor(Mentor mentor) {
		mapOfMentor.put(mentor.getId(), mentor);
	}

	public Mentor listMentor(String id) {
		return mapOfMentor.get(id);
	}

	public Map<String, Mentor> getMapOfMentor() {
		return mapOfMentor;
	}

}
