
package com.mentor.rest.model;


public class Technology {

	private String id;
	private String skillname;
	private String toc;
	private String prerequisites;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getSkillName() {
		return skillname;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setSkillName(String skillname) {
		this.skillname = skillname;
	}

	public String getTOC() {
		return toc;
	}

	public void setTOC(String toc) {
		this.toc = toc;
	}

	public String getPrerequisites() {
		return prerequisites;
	}

	public void setPrerequisites(String prerequisites) {
		this.prerequisites = prerequisites;
	}

}
