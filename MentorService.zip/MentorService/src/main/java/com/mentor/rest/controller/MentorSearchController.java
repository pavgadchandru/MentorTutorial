package com.mentor.rest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MentorSearchController {

@RequestMapping("/mentorSearch")
public String mentorSearch() {
	@Autowired
	private MentorService mentorService;

	@RequestMapping(value = "/mentor/search", method = RequestMethod.PUT, consumes={MediaType.APPLICATION_JSON_VALUE})
	public void findMentors(@RequestBody Mentor mentor) {
		mentorService.findMentors(mentor);
	}

	@RequestMapping(value = "/mentor/list", method = RequestMethod.GET)
	public ResponseEntity<List<Mentor>> list() {
		List<Mentor> mentors = new ArrayList<Mentor>(mentorService.getMapOfMentors().values());
		return new ResponseEntity<List<Mentor>>(mentors, HttpStatus.OK);
	}
}


}