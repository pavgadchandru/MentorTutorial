package com.mentor.rest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserLoginRestController {

@RequestMapping("/userlogin")
public String userValidation() {
	return "User: Successfully logged in!";
}

@RequestMapping("/adminlogin")
public String adminValidation() {
	return "Admin: Successfully logged in!";
}
}