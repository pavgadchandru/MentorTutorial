package com.mentor.rest;

import org.springframework.boot.SpringApplication;


@SpringBootApplication
public class UserLoginRestMain {
public static void main(String[] args) {
	SpringApplication.run(UserLoginRestMain.class, args);
}
}
