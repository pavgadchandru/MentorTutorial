package com.mentor.rest.dao.service;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

public class MentorSearchService {

public String mentorSearchService() {
	
}

}