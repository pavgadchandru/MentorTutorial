
package com.mentor.rest.dao;

import java.util.Map;

import com.mentor.rest.model.Mentor;


public interface MentorService {
	
	public void searchMentor(Mentor mentor);

	public Mentor getMentor(String id);
	
	public Map<String, Mentor> getMapOfMentor();
}
